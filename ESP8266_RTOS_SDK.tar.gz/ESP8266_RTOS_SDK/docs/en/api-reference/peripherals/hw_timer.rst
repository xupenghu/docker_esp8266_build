Hardware Timer
==============

API Reference
-------------

.. include:: /_build/inc/hw_timer.inc