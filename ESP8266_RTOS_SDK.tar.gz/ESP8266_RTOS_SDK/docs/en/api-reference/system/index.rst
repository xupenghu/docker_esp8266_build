System API
**********

.. toctree::
   :maxdepth: 1

   Heap Memory Allocation <mem_alloc>
   Heap Memory Debugging <heap_debug>
   Watchdogs <wdts>
   Logging <log>
   Sleep Modes <sleep_modes>
   Miscellaneous System APIs <system>
