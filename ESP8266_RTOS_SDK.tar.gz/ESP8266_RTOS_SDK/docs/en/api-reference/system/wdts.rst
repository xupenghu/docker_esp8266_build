Watch dog task
==============

API Reference
-------------

.. include:: /_build/inc/esp_task_wdt.inc