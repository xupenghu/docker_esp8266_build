Mem alloc
==========

API Reference
-------------

.. include:: /_build/inc/esp_heap_caps.inc
.. include:: /_build/inc/esp_heap_caps_init.inc