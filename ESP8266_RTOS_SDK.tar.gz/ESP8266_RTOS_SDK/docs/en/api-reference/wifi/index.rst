Wi-Fi API
*********

.. toctree::
   :maxdepth: 1

   Wi-Fi <esp_wifi>
   Smart Config <esp_smartconfig>


Example code for this API section is provided in :example:`wifi` directory of SDK examples.
