Smart Config
============

API Reference
-------------

.. include:: /_build/inc/esp_smartconfig.inc
